# Data files for the *ncTiledViewer* project

## Maps

- The Tiled XML files and the PNG tilesets have been copied from the `tiled/examples` directory.

## Icons

- The images in the `icons` folder have been created by Angelo Theodorou for the ncTiledViewer project by modifying the original Tiled icon and are distributed under the terms of the *Creative Commons Attribution-ShareAlike 4.0 International License*
